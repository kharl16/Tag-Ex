import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Mail, Phone, MapPin, Globe, Download, Facebook, Linkedin, Instagram, Twitter, Github, MessageCircle, Music, Youtube } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";
import { toast } from "sonner";
import LoadingAnimation from "@/components/LoadingAnimation";
import ProductRingCarousel from "@/components/ProductRingCarousel";

type CardData = Tables<"cards">;
type ProductImageData = Tables<"product_images">;

interface SocialLink {
  id: string;
  kind: string;
  label: string;
  value: string;
  icon: string;
}

const iconMap: Record<string, React.FC<React.SVGProps<SVGSVGElement>>> = {
  Facebook: Facebook,
  Linkedin: Linkedin,
  Instagram: Instagram,
  Twitter: Twitter,
  Youtube: Youtube,
  Github: Github,
  MessageCircle: MessageCircle,
  Music: Music,
  Globe: Globe,
};

const socialBrandColors: Record<string, string> = {
  facebook: "bg-[#1877F2]",
  linkedin: "bg-[#0A66C2]",
  instagram: "bg-gradient-to-br from-[#833AB4] via-[#E1306C] to-[#FD1D1D]",
  x: "bg-black",
  youtube: "bg-[#FF0000]",
  telegram: "bg-[#26A5E4]",
  tiktok: "bg-black",
  url: "bg-[#4285F4]",
};

const contactBrandColors: Record<string, string> = {
  email: "bg-[#EA4335]",
  phone: "bg-[#34A853]",
  website: "bg-[#4285F4]",
  location: "bg-[#FBBC04]",
};

export default function PublicCard() {
  const { slug } = useParams();
  const [card, setCard] = useState<CardData | null>(null);
  const [socialLinks, setSocialLinks] = useState<SocialLink[]>([]);
  const [productImages, setProductImages] = useState<ProductImageData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCard();
  }, [slug]);

  const loadCard = async () => {
    if (!slug) return;

    const { data, error } = await supabase
      .from("cards")
      .select("*")
      .eq("slug", slug)
      .eq("is_published", true)
      .single();

    if (!error && data) {
      setCard(data);
      // Track view through Edge Function (with rate limiting)
      supabase.functions.invoke('track-card-event', {
        body: { card_id: data.id, kind: 'view' }
      }).catch(err => console.error('Failed to track view:', err));
      
      // Load social links
      const { data: links } = await supabase
        .from("card_links")
        .select("*")
        .eq("card_id", data.id)
        .in("kind", ["facebook", "linkedin", "instagram", "x", "youtube", "telegram", "tiktok", "url"])
        .order("sort_index");
      
      if (links) {
        setSocialLinks(links.map(link => ({
          id: link.id,
          kind: link.kind,
          label: link.label,
          value: link.value,
          icon: link.icon || "",
        })));
      }

      // Load product images
      const { data: images } = await supabase
        .from("product_images")
        .select("id, image_url, alt_text, description, sort_order")
        .eq("card_id", data.id)
        .order("sort_order", { ascending: true });
      
      if (images) {
        setProductImages(images);
      }
    }
    setLoading(false);
  };

  if (loading) {
    return <LoadingAnimation />;
  }

  if (!card) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="mb-2 text-4xl font-bold">404</h1>
          <p className="text-muted-foreground">Card not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-2xl">
        <Card className="overflow-hidden border-0 rounded-none shadow-lg">
          {/* Header with cover image */}
          <div className="relative h-48 sm:h-56 md:h-64 bg-gradient-to-br from-primary/20 to-primary/5">
            {card.cover_url && (
              <>
                <img src={card.cover_url} alt="Cover" className="h-full w-full object-contain" />
                {/* Subtle bottom gradient overlay for contrast without blurring the image */}
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/80 via-background/30 to-transparent"></div>
              </>
            )}
            
            {/* Avatar - Bottom Left - Half overlapping the cover */}
            <div className="absolute -bottom-12 left-6 h-24 w-24 sm:h-28 sm:w-28 md:h-32 md:w-32 rounded-full border-4 border-background bg-muted overflow-hidden shadow-2xl ring-4 ring-black/10 hover:scale-105 transition-transform duration-300">
              {card.avatar_url && (
                <img src={card.avatar_url} alt={card.full_name} className="h-full w-full object-cover" />
              )}
            </div>
            
            {/* Logo - Bottom Right - Half overlapping the cover */}
            {card.logo_url && (
              <div className="absolute -bottom-10 right-6 h-20 w-32 sm:h-24 sm:w-36 md:h-28 md:w-40 rounded-lg bg-black/90 p-1.5 shadow-2xl ring-4 ring-black/10 hover:scale-105 transition-transform duration-300">
                <img src={card.logo_url} alt="Logo" className="h-full w-full object-contain" />
              </div>
            )}
          </div>

          {/* Profile Info */}
          <div className="px-6 pt-16 pb-4">
            <h1 className="text-2xl font-bold">{card.full_name}</h1>
            {card.title && <p className="text-lg text-foreground/80 mt-1">{card.title}</p>}
            {card.company && <p className="text-sm text-muted-foreground">{card.company}</p>}
            {card.bio && <p className="mt-3 text-sm text-muted-foreground">{card.bio}</p>}
          </div>

          {/* Product Carousel */}
          {(card.carousel_enabled !== false) && productImages.length > 0 && (
            <div className="my-6">
              <ProductRingCarousel cardId={card.id} />
            </div>
          )}

          {/* Social Media Links */}
          {socialLinks.length > 0 && (
            <div className="flex flex-wrap gap-3 justify-center px-6 pb-4">
              {socialLinks.map((link) => {
                const IconComponent = iconMap[link.icon] || Globe;
                const brandColor = socialBrandColors[link.kind] || "bg-primary";
                return (
                  <a
                    key={link.id}
                    href={link.value}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex h-12 w-12 items-center justify-center rounded-full ${brandColor} hover:scale-110 hover:opacity-90 transition-all duration-200 cursor-pointer shadow-md`}
                    title={link.label}
                  >
                    <IconComponent className="h-6 w-6 text-white" />
                  </a>
                );
              })}
            </div>
          )}

          {/* Contact Buttons */}
          <div className="space-y-3 px-6 pb-6">
            {card.email && (
              <button
                onClick={() => window.open(`mailto:${card.email}`)}
                className="flex w-full items-center gap-3 text-left group"
              >
                <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${contactBrandColors.email} group-hover:scale-110 transition-transform duration-200 shadow-md`}>
                  <Mail className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{card.email}</p>
                  <p className="text-xs text-muted-foreground">Personal</p>
                </div>
              </button>
            )}

            {card.phone && (
              <button
                onClick={() => window.open(`tel:${card.phone}`)}
                className="flex w-full items-center gap-3 text-left group"
              >
                <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${contactBrandColors.phone} group-hover:scale-110 transition-transform duration-200 shadow-md`}>
                  <Phone className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold">{card.phone}</p>
                  <p className="text-xs text-muted-foreground">Mobile</p>
                </div>
              </button>
            )}

            {card.website && (
              <button
                onClick={() => window.open(card.website!, "_blank")}
                className="flex w-full items-center gap-3 text-left group"
              >
                <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${contactBrandColors.website} group-hover:scale-110 transition-transform duration-200 shadow-md`}>
                  <Globe className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{card.website}</p>
                  <p className="text-xs text-muted-foreground">Website</p>
                </div>
              </button>
            )}

            {card.location && (
              <div className="flex w-full items-center gap-3">
                <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${contactBrandColors.location} shadow-md`}>
                  <MapPin className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold">{card.location}</p>
                  <p className="text-xs text-muted-foreground">Location</p>
                </div>
              </div>
            )}
          </div>

          {/* QR Code */}
          {card.qr_code_url && (
            <div className="flex flex-col items-center gap-3 p-6 bg-muted/30">
              <img 
                src={card.qr_code_url} 
                alt="QR Code" 
                className="w-48 h-48 rounded-lg border border-border"
              />
              <a 
                href={card.qr_code_url} 
                download={`${card.slug}-qr.png`}
                className="text-sm text-primary hover:underline flex items-center gap-2"
              >
                <Download className="h-4 w-4" />
                Download QR Code
              </a>
            </div>
          )}
        </Card>

        {/* Save Contact Button */}
        <div className="mt-6 space-y-3">
          <Button 
            className="w-full gap-2 bg-green-500 hover:bg-green-600"
            onClick={async () => {
              try {
                const response = await fetch(
                  `https://lorowpouhpjjxembvwyi.supabase.co/functions/v1/generate-vcard`,
                  {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                      card_id: card.id,
                      include_photo: true,
                    }),
                  }
                );

                if (!response.ok) throw new Error('Failed to generate vCard');

                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `${card.full_name.replace(/\s+/g, '-')}.vcf`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
                
                toast.success("Contact saved with photo!");
              } catch (error) {
                console.error('Error downloading vCard:', error);
                toast.error("Failed to save contact");
              }
            }}
          >
            <Download className="h-4 w-4" />
            Download vCard (.vcf)
          </Button>
          
          <Button 
            variant="outline"
            className="w-full gap-2"
            onClick={async () => {
              try {
                const response = await fetch(
                  `https://lorowpouhpjjxembvwyi.supabase.co/functions/v1/generate-vcard`,
                  {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                      card_id: card.id,
                      include_photo: false,
                    }),
                  }
                );

                if (!response.ok) throw new Error('Failed to generate vCard');

                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `${card.full_name.replace(/\s+/g, '-')}.vcf`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
                
                toast.success("Contact saved without photo");
              } catch (error) {
                console.error('Error downloading vCard:', error);
                toast.error("Failed to save contact");
              }
            }}
          >
            <Download className="h-4 w-4" />
            Download vCard (no photo)
          </Button>
          
          <p className="text-xs text-muted-foreground text-center">
            If your phone doesn't import, try the 'no photo' option.
          </p>
        </div>
      </div>
    </div>
  );
}
