export const SITE_ORIGIN =
  (typeof import.meta !== "undefined" && import.meta.env?.VITE_PUBLIC_SITE_URL) ||
  (typeof window !== "undefined" ? window.location.origin : "https://tagex.app");

export const cardUrl = (slug: string) => `${SITE_ORIGIN}/c/${slug}`;