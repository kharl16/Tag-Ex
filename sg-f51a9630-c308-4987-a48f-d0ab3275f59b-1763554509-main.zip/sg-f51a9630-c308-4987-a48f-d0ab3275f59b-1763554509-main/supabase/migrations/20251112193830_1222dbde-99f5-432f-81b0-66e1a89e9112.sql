-- Remove legacy tables from previous project
-- These tables are not part of the Card-Ex application

DROP TABLE IF EXISTS public."Branches and IBCs";
DROP TABLE IF EXISTS public."Files";